//// JavaScript Document
        $(function() {

            $(".slide-trigger").click(function() {
                $(".nav").toggle("fast");
            });
        });
        
        
        $(window).resize(function() {
    var width = $(window).width();
    if (width < 880) {
        $('.nav').hide();
    }
    else {
        
        $('.nav').show();

         }
});

///////////////////////////////////////////

$(document).ready(function(){
  $('nav li ul').css({
    display: "none",
    left: "0"
  });
  $('nav li').hover(function() {
    $(this)
      .find('ul')
      .stop(true, true)
      .slideDown('fast');
  }, function() {
    $(this)
      .find('ul')
      .stop(true,true)
      .slideUp('slow');
  });
});

/////////////////////////////////////////////////////////////////////////////////////////////////////

    // find menu items with children.
$(document).ready(function(){
    $(this).find('li').has('ul').addClass('has-menu')
    .find('a:first').append('<span class="arrow">&#43;</span>');
});
/////////////////////////////////////////////////////////////////////////////////////////////////////


  			$(document).ready(function(){ 
			
			$(window).scroll(function(){
				if ($(this).scrollTop() > 100) {
					$('.scrollup').fadeIn();
				} else {
					$('.scrollup').fadeOut();
				}
			}); 
			
			$('.scrollup').click(function(){
				$("html, body").animate({ scrollTop: 0 }, 600);
				return false;
			});
 
		});
		
		
		
//////////////////////////////////////////////////////////////////////////////////////	